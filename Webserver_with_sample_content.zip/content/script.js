// Test a delayed function
setTimeout(myFunction, 2000);

function myFunction() {
    var node = document.getElementById('blah');
    node.innerHTML = Date.now();
	
	// Test an XHR from the server
	$.ajax({
		url: 'dynamictext.txt'
	}).done(function (data) {
		$('#dynamictext').html(data);
	});
}